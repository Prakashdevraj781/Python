
import win32com.client
import sqlalchemy
import streamlit_authenticator as sw
import streamlit as st
from streamlit_option_menu import option_menu
import pickle
import os
import pandas as pd
import pyodbc as py
import yaml
import warnings
warnings.filterwarnings('ignore')

conn_str = (
    r'DRIVER={SQL Server};'
    r'SERVER=UG-BLR-L262;'
    r'database =AdventureWorksDW2008R2;'
    r'username=ETLdemo;'
    r'password=Devraj@@1;'
    r'Trusted_Connection=yes;'
)


st.set_page_config(page_title="AB Testing", page_icon=":smiley:",layout="wide")

with open('config.yaml') as file:
    config = yaml.safe_load(file)
authenticator = sw.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)


name, authentication_status, username = authenticator.login('Login', 'main')

if authentication_status == None:
    st.warning("please enter username and passwords")

if authentication_status == False:
    try:
        username_forgot_pw, email_forgot_password, random_password = authenticator.forgot_password('Forgot password',        'sidebar')
        if username_forgot_pw:
            st.sidebar.success('New password sent securely')
            # Random password to be transferred to user securely
        elif username_forgot_pw == False:
            st.sidebar.error('Username not found')
    except Exception as e:
        st.sidebar.error(e)
    
    try:
        username_forgot_username, email_forgot_username = authenticator.forgot_username('Forgot username','sidebar')
        if username_forgot_username:
            st.sidebar.success('Username sent securely')
            # Username to be transferred to user securely
        elif username_forgot_username == False:
            st.sidebar.error('Email not found')
    except Exception as e:
        st.sidebar.error(e)
    
    st.error("Username/password is incorrect")

if authentication_status:
    
    if st.session_state["authentication_status"]:
        authenticator.logout('Logout', 'sidebar')
        st.sidebar.write(f'Welcome *{st.session_state["name"]}*')
    elif st.session_state["authentication_status"] == False:
        st.error('Username/password is incorrect')
    elif st.session_state["authentication_status"] == None:
        st.warning('Please enter your username and password')
    with st.sidebar:
        selected = option_menu(menu_title="Main menu",
                           options=["Submit Data", "Display Data", "Upload data", "Reset password"])
    
    def save_uploaded_file(uploadedfiles):
        with open(os.path.join("C:\\Users\\prakash.raj\\Downloads\\sampledatafoodsales\\user_uploads\\",uploadedfiles.name),"wb") as f:
            f.write(uploadedfiles.getbuffer())
            return st.success("{} is uploaded".format(uploadedfiles.name))
        
        
    if selected== "Reset password":
        if authentication_status:
            try:
                if authenticator.reset_password(username, 'Reset password'):
                    st.success('Password modified successfully')
                    with open('config.yaml','w') as file:
                        yaml.dump(config, file, default_flow_style=False)
            except Exception as e:
                st.error(e)

    
    if selected== "Submit Data":
        st.title(":chart: AB Test Detail")
        st.session_state['flag']='1'
        st.write("Enter the details of Test")
        st.markdown("""---""")
        st.write("please enter your details")
        name = st.text_input("Enter Your Test name")
        job =st.text_input("Enter your filters")
        age = st.number_input("Enter test duration", min_value=0, max_value=100)
        Test_status = st.checkbox("Available for work")
        if Test_status:
            Day_available = st.slider("Pick a threshold", min_value=1, max_value=8, value=0, step=1)
        Lunch = st.selectbox("Customer Type", ['select preference',"B2C", "B2B", "Contractual", "LTC"],0)
        if Lunch =='B2C':
            combo = st.selectbox("choose your combo",['Select',"Community1", "Community2"],0)
        elif Lunch =='Contractual':
            combo = st.selectbox("choose your combo",["Less then 3 months"," 1 year", "6 months"])
        elif Lunch =="B2B":
            combo = st.selectbox("choose your combo",['Select',"LG","BEHR","RIGID"],0)
        uploaded_files = st.file_uploader("Choose a CSV file", accept_multiple_files=True, type=['CSV'])
        for uploaded_file in uploaded_files:
            bytes_data = uploaded_file.read()
        
        if st.button('Submit Data'):
            st.write('Data submitted sucessfully')
            st.session_state['variable0'] = name
            st.session_state['variable1'] = age
            st.session_state['variable2'] = job
            st.session_state['variable3'] = Lunch
            st.session_state['variable4'] = Day_available
            st.session_state['variable5'] = uploaded_file.name
            save_uploaded_file(uploaded_file)
            
            st.session_state['flag']='0'
        
    
    if selected== "Display Data":
        st.title(":chart: AB Test Data") 
        left_column, middle_column,right_column = st.columns(3)
        with left_column:
            st.write("Please Find the details below")
            if st.button('Display Recent Data'):
                try:
                    cnxn=py.connect(conn_str)
                    cursor =cnxn.cursor()
                    Select_query = """Select Top 5 * from ETLtest.dbo.Employee"""
                    df=pd.read_sql(Select_query,cnxn)
                    st.dataframe(df, width=6000)
                except exception as err:
                    st.write('Error while retrieving the data', err)     
                finally:
                    cnxn.close()

        with right_column:
            Search_key = st.selectbox("Choose Parameter",['select preference',"Name", "Job", "Lunch"])
            val = st.text_input('Enter here')
            if st.button('Search Data'):
                
                try:
                    cnxn=py.connect(conn_str)
                    cursor =cnxn.cursor()
                    query = """Select * from ETLtest.dbo.Employee where {} ='{}';""".format(Search_key,val)               
                    df1=pd.read_sql(query,cnxn)
                    st.dataframe(df1, width=6000)
                except:
                    st.write('Error while searching the data')     
                finally:
                    cnxn.close()

        
       
    
    if selected== "Upload data":
        st.title(":chart: Upload AB Test Deta") 
        if st.session_state['flag']=='1':
            st.write(f"""
         * Notification :Could only updaload data after data submission""")
        else:
            st.markdown(f"""
             * name :{st.session_state['variable0']}
             * Job : {st.session_state['variable1']}
             * Age : {st.session_state['variable2']}
             * Lunch : {st.session_state['variable3']}
             * Availability : {st.session_state['variable4']}
             * File uploaded : {st.session_state['variable5']}
             """)
            if st.button('Upload Data'):
                st.write('Uploading above data...')
                try:
                    cnxn=py.connect(conn_str)
                    cursor =cnxn.cursor()
                    insert_query = """insert into ETLtest.dbo.Employee(Name,Job,Age,Lunch,Availability) 
                       values  ('{}','{}',{},'{}','{}');""".format(name,job,age,Lunch,Hours_available)
                    cursor.execute(insert_query)
                    cnxn.commit()
                except exception as err:
                    st.write('Error while inserting the data ', err)     
                finally:
                    st.write('Data uploaded Sucessfully')
                    cursor.close()
                    cnxn.close()




            