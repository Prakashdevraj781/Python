import pandas as pd
import streamlit as st
import plotly.express as px
import warnings
warnings.filterwarnings('ignore')
st.set_page_config(page_title="Sales Dashboard", page_icon=":bar_chart:",layout="wide")
df = pd.read_excel("C:\\Users\\prakash.raj\\Documents\\Dashboard.xlsx", sheet_name='raw')

#----sidebar----

st.sidebar.header("Please Filter Here:")
City=st.sidebar.multiselect("select the City:", options=df["City"].unique(), default=df["City"].unique())
Region=st.sidebar.multiselect("select the Region:", options=df["Region"].unique(), default=df["Region"].unique())
Category=st.sidebar.multiselect("select the Category:", options=df["Category"].unique(), default=df["Category"].unique())

df_selection = df.query(
    "City == @City & Region == @Region & Category == @Category")

#st.dataframe(df_selection)

#----Mainpage-----
st.title(":bar_chart: Sales Dashboard")
st.markdown("##")

#Top KPI's
TotalPrice = int(df_selection["TotalPrice"].sum())
Average_Sales = round(df_selection["TotalPrice"].mean(), 2)
Rating = ":star:" * int(df_selection["TotalPrice"].mean()/30)

left_column, middle_column,right_column = st.columns(3)
with left_column:
    st.subheader("Total_sales")
    st.subheader(f"US $ {TotalPrice:,}")

with middle_column:
    st.subheader("Average_Sales")
    st.subheader(f"US $ {Average_Sales:,}")

with right_column:
    st.subheader("Rating")
    st.subheader(f"{Rating:}")
    
    
    
st.markdown("---")

#sales by product[bar chart]
sales_by_product =(df_selection.groupby(by=["Product"]).sum()[["TotalPrice"]].sort_values(by="TotalPrice"))
sales_by_Category =(df_selection.groupby(by=["Category"]).sum()[["TotalPrice"]].sort_values(by="TotalPrice"))
sales_by_city =(df_selection.groupby(by=["City"]).sum()[["TotalPrice"]].sort_values(by="TotalPrice"))



fig_product_sales =px.bar(sales_by_product,
                          x=sales_by_product.index,
                          y="TotalPrice",
                          title="<b> Sales by Product </b>",
                          template="plotly_dark"
                         )

fig_product_sales.update_layout(plot_bgcolor="rgba(0,0,0,0)", xaxis=(dict(showgrid=False)))

fig_product_sales1 =px.bar(sales_by_Category,
                          x=sales_by_Category.index,
                          y="TotalPrice",
                          title="<b> Sales by Category </b>",
                          template="plotly_dark")

fig_product_sales1.update_layout(plot_bgcolor="rgba(0,0,0,0)", xaxis=(dict(showgrid=False)))

fig_product_sales2 =px.bar(sales_by_city,
                          x=sales_by_city.index,
                          y="TotalPrice",
                          title="<b> Sales by City </b>",
                          template="plotly_dark")

fig_product_sales2.update_layout(plot_bgcolor="rgba(0,0,0,0)", xaxis=(dict(showgrid=False)))

#st.plotly_chart(fig_product_sales)
#st.plotly_chart(fig_product_sales1)
#st.plotly_chart(fig_product_sales2)

left_column, middle_column, right_column =st.columns(3)
left_column.plotly_chart(fig_product_sales, use_container_width=True)
middle_column.plotly_chart(fig_product_sales1, use_container_width=True)
right_column.plotly_chart(fig_product_sales2, use_container_width=True)

hide_st_style ="""
                <style>
                MainMenu {visibility : hiddenn;}
                Header {visibility : hiddenn;}
                Footer {visibility : hiddenn;}
                </style>
                """
st.markdown(hide_st_style, unsafe_allow_html=True)
    
    
    
    
    
