import win32com.client
import sqlalchemy
import streamlit_authenticator as sw
import streamlit as st
from streamlit_option_menu import option_menu
import pickle
import os
import pandas as pd
import pyodbc as py
import yaml
import warnings

st.set_page_config(page_title="Login", page_icon=":chart:",layout="wide")

with open('config.yaml') as file:
    config = yaml.safe_load(file)
authenticator = sw.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)
name, authentication_status, username = authenticator.login('Login', 'main')
if authentication_status == False:
    st.error("Username/password is incorrect")
if authentication_status == None:
    st.warning("please enter username and passwords")
if authentication_status:
    st.title(":chart: Employee Detail")
